var express = require('express');
var path = require('path');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var port = 3000;
var nuevaFicha;
app.use(express.static(path.join(__dirname, "public")));

io.on('connection', (socket) => {
    console.log('nueva conexion');

    socket.on('nuevaFicha', function (ficha) {
        nuevaFicha = ficha;
        console.log(nuevaFicha);
        socket.broadcast.emit('rellamar', nuevaFicha);
    });
/*    socket.broadcast.emit('rellamar', nuevaFicha);*/

    socket.emit('saludo', 'hola');
});

server.listen(port, () => {
    console.log("Listening on port " + port);
});
